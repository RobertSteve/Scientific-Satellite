<?php if (!defined('ABSPATH')) exit; ?>

<div class="row">
    <div class="col-md-12">
        <h4><?php _e('Main Content', 'motopress-slider'); ?></h4>
    </div>
</div>