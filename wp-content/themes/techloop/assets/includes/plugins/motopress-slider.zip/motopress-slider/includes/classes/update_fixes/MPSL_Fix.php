<?php

/**
 * Interface MPSL_Fix
 * Every class that implements interface must be named as "MPSL_Fix_v{$version}", where $version without dots.
 */
interface MPSL_Fix {}